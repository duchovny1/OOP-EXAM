﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public interface IEmptyBus
    {
        void IsTheBusEmpty(bool isEmpty);
    }
}
